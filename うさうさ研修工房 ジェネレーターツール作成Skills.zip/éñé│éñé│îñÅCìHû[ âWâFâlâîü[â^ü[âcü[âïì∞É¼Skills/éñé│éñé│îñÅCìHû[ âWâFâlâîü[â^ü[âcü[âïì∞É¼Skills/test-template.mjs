/* ============================================================
   うさうさ研修工房 ／ テストテンプレート
   使い方（Windows PowerShell）:
     npm init -y
     npm install --save-dev jsdom
     node --test "tests/*.test.mjs"
   package.json に "type": "module" を足しておくこと。
   ※ ディレクトリ名だけを渡す `node --test tests\` は Node 22 で
     MODULE_NOT_FOUND になる。上のようにグロブで指定する。
   ※ このテンプレートは Node v22.22.2 + jsdom で全40項目パスを確認済み。
   ============================================================
   構成:
     A. 単体テスト  … generate / validate だけを直接呼ぶ。DOMなし。速い
     B. 結合テスト  … jsdomでHTMLを読み込み、ボタンを押して確かめる
     C. システムテスト … ここには書けない。実ブラウザで人間が触る
   ============================================================ */

import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { JSDOM } from "jsdom";

const HTML_PATH = new URL("../mail-generator-v1.0.html", import.meta.url);
const html = readFileSync(HTML_PATH, "utf8");

/* HTMLの <script> から純粋関数だけを取り出して評価する。
   単一HTMLでもロジックを単体テストできるようにするための工夫。 */
function loadPureFunctions(){
  const dom = new JSDOM(html, { runScripts: "dangerously", pretendToBeVisual: true });
  return dom.window;
}

/* ============================================================
   A. 単体テスト
   ============================================================ */

describe("validate（入力チェック）", () => {
  const w = loadPureFunctions();
  const { validate } = w;

  test("必須が埋まっていれば通る", () => {
    assert.equal(validate({ recipient:"株式会社ABC", purpose:"request", body:"" }).ok, true);
  });

  test("空文字は弾く", () => {
    assert.equal(validate({ recipient:"", purpose:"request" }).ok, false);
  });

  test("半角スペースのみは弾く", () => {
    assert.equal(validate({ recipient:"   ", purpose:"request" }).ok, false);
  });

  test("全角スペースのみは弾く ← 日本語ツール頻出バグ", () => {
    assert.equal(validate({ recipient:"　　", purpose:"request" }).ok, false);
  });

  test("改行のみは弾く", () => {
    assert.equal(validate({ recipient:"\n\n", purpose:"request" }).ok, false);
  });

  test("1文字（最小境界）は通る", () => {
    assert.equal(validate({ recipient:"あ", purpose:"request" }).ok, true);
  });

  test("本文2000文字ちょうどは通る", () => {
    assert.equal(validate({ recipient:"A", purpose:"request", body:"あ".repeat(2000) }).ok, true);
  });

  test("本文2001文字は弾く（上限+1）", () => {
    const r = validate({ recipient:"A", purpose:"request", body:"あ".repeat(2001) });
    assert.equal(r.ok, false);
    assert.ok(r.errors.includes("errBodyLong"));
  });
});

describe("generate（生成ロジック）", () => {
  const w = loadPureFunctions();
  const { generate } = w;
  const base = { recipient:"株式会社ABC", purpose:"request", body:"打ち合わせの件です。" };

  test("宛名が先頭に出る", () => {
    assert.ok(generate(base).text.startsWith("株式会社ABC 御中"));
  });

  test("本文が含まれる", () => {
    assert.ok(generate(base).text.includes("打ち合わせの件です。"));
  });

  test("同じ入力なら必ず同じ出力（決定性）", () => {
    assert.equal(generate(base).text, generate(base).text);
  });

  test("入力オブジェクトを書き換えない（副作用なし）", () => {
    const input = { ...base };
    const snapshot = JSON.stringify(input);
    generate(input);
    assert.equal(JSON.stringify(input), snapshot);
  });

  test("本文が空なら本文行を出さない", () => {
    const out = generate({ ...base, body:"" }).text;
    assert.ok(!out.includes("\n\n\n\n"));
  });

  test("前後の空白はtrimされる", () => {
    assert.ok(generate({ ...base, recipient:"  株式会社ABC  " }).text.startsWith("株式会社ABC"));
  });

  test("テンプレートの差し込みが残らない", () => {
    assert.ok(!/\{\{.*?\}\}/.test(generate(base).text));
  });

  test("全用件で分岐が通る", () => {
    for(const p of ["request","report","thanks"]){
      assert.ok(generate({ ...base, purpose:p }).text.length > 0, p);
    }
  });

  test("未知の用件は既定値にフォールバックする", () => {
    assert.ok(generate({ ...base, purpose:"unknown" }).text.length > 0);
  });

  test("英語モードで英語の文言が出る", () => {
    const out = generate(base, "en").text;
    assert.ok(!out.includes("御中"));
  });

  test("絵文字・サロゲートペアで壊れない", () => {
    assert.ok(generate({ ...base, recipient:"🐰𠮷野家" }).text.includes("🐰"));
  });

  test("環境依存文字で壊れない", () => {
    assert.ok(generate({ ...base, recipient:"㈱髙﨑①" }).text.includes("㈱髙﨑①"));
  });

  test("HTML特殊文字がそのまま文字列として保持される", () => {
    const out = generate({ ...base, body:"<script>alert(1)</script>" }).text;
    assert.ok(out.includes("<script>"));
  });

  test("超長文でも生成できる", () => {
    assert.ok(generate({ ...base, body:"あ".repeat(2000) }).text.length > 2000);
  });
});

/* ============================================================
   B. 結合テスト（DOM込み）
   ============================================================ */

describe("画面操作", () => {
  function freshDom(){
    const dom = new JSDOM(html, { runScripts:"dangerously", pretendToBeVisual:true, url:"https://example.test/" });
    return dom.window.document;
  }

  test("初期状態でコピー・DLボタンが無効", () => {
    const d = freshDom();
    assert.equal(d.getElementById("btnCopy").disabled, true);
    assert.equal(d.getElementById("btnDownload").disabled, true);
  });

  test("必須未入力で生成するとエラー帯が出る", () => {
    const d = freshDom();
    d.getElementById("btnGenerate").click();
    const n = d.getElementById("notice");
    assert.equal(n.hidden, false);
    assert.equal(n.dataset.tone, "error");
  });

  test("生成するとコピー・DLが有効になる", () => {
    const d = freshDom();
    d.getElementById("recipient").value = "株式会社ABC";
    d.getElementById("btnGenerate").click();
    assert.equal(d.getElementById("btnCopy").disabled, false);
    assert.equal(d.getElementById("btnDownload").disabled, false);
  });

  test("結果は textContent で入る（HTMLとして解釈されない）", () => {
    const d = freshDom();
    d.getElementById("recipient").value = "A";
    d.getElementById("body").value = "<b>太字</b>";
    d.getElementById("btnGenerate").click();
    const box = d.getElementById("result");
    assert.equal(box.querySelector("b"), null);
    assert.ok(box.textContent.includes("<b>太字</b>"));
  });

  test("生成を10回押しても結果が累積しない", () => {
    const d = freshDom();
    d.getElementById("recipient").value = "A";
    d.getElementById("btnGenerate").click();
    const once = d.getElementById("result").textContent;
    for(let i=0;i<9;i++) d.getElementById("btnGenerate").click();
    assert.equal(d.getElementById("result").textContent, once);
  });

  test("クリアで初期状態に戻る", () => {
    const d = freshDom();
    d.getElementById("recipient").value = "A";
    d.getElementById("btnGenerate").click();
    d.getElementById("btnClear").click();
    assert.equal(d.getElementById("recipient").value, "");
    assert.equal(d.getElementById("btnCopy").disabled, true);
  });

  test("文字数カウンタが入力に追従する", () => {
    const d = freshDom();
    const ta = d.getElementById("body");
    ta.value = "あいうえお";
    ta.dispatchEvent(new d.defaultView.Event("input"));
    assert.equal(d.getElementById("bodyCount").textContent, "5");
  });

  test("言語を切り替えると見出しが変わる", () => {
    const d = freshDom();
    const sel = d.getElementById("lang");
    const before = d.getElementById("h-input").textContent;
    sel.value = "en";
    sel.dispatchEvent(new d.defaultView.Event("change"));
    assert.notEqual(d.getElementById("h-input").textContent, before);
  });

  test("辞書にないキーでもキー名が画面に出ない", () => {
    const d = freshDom();
    /* body.textContent には <script> の中身も入るので、
       表示されるテキストだけを集めて判定する */
    const clone = d.body.cloneNode(true);
    clone.querySelectorAll("script, style").forEach(el => el.remove());
    const visible = clone.textContent;
    assert.ok(!visible.includes("data-i18n"));
    assert.ok(!/\bbtnGenerate\b/.test(visible));
  });

  test("全入力欄に label が紐づいている", () => {
    const d = freshDom();
    for(const el of d.querySelectorAll("input, select, textarea")){
      const hasLabel = d.querySelector(`label[for="${el.id}"]`) || el.closest("label");
      assert.ok(hasLabel, `label がない: #${el.id}`);
    }
  });

  test("結果パネルに aria-live がある", () => {
    const d = freshDom();
    assert.equal(d.getElementById("result").getAttribute("aria-live"), "polite");
  });
});

/* ============================================================
   静的検査（制約違反の自動検出）
   ============================================================ */

describe("うさうさ制約", () => {
  test("外部リソースを参照していない（CDN不使用）", () => {
    assert.ok(!/(src|href)\s*=\s*["']https?:\/\//i.test(html), "外部URL参照がある");
  });

  test("@import で外部CSSを読んでいない", () => {
    assert.ok(!/@import\s+url\(\s*["']?https?:/i.test(html));
  });

  test("ユーザー入力に innerHTML を使っていない", () => {
    assert.ok(!/\.innerHTML\s*=/.test(html), "innerHTML への代入がある");
  });

  test("入力欄のフォントが16px以上", () => {
    assert.ok(/font-size:\s*16px/.test(html));
  });

  test("色が :root のCSS変数で定義されている", () => {
    assert.ok(/--rd-rose:/.test(html));
  });

  test("バージョン刻印がフッターにある", () => {
    assert.ok(/v\d+\.\d+/.test(html));
  });

  test("タグラインの誤記がない", () => {
    assert.ok(!html.includes("面白きなき世を面白く"), "タグラインが誤記");
  });
});

/* ============================================================
   C. システムテスト（自動化できない。手で確認して記録する）
   tests/checklist.md に結果を残すこと。
     □ 実ブラウザ4種で表示・生成・コピー・DL
     □ file:// で開いてコピーが動く
     □ 機内モードで全機能が動く
     □ DevTools Network に外部リクエストが1件も出ない
     □ 375px / 1280px で表示崩れなし
     □ キーボードのみで 入力→生成→コピー
     □ ベル音が鳴る（Safari含む）
   ============================================================ */
