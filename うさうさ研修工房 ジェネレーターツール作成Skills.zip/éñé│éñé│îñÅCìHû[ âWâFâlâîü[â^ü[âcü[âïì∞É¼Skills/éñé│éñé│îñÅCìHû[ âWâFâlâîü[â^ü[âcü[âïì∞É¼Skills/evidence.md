# 科学的根拠（査読済み論文）

このスキルが「新人向け」と「中級向け」で支援の粒度を変える理由、およびテストをチェックリスト化する理由の出典。

**掲載基準**：査読付き学術誌に掲載された論文のみ。書誌情報（誌名・巻号・ページ・DOI）は実在確認済み。研修資料や記事に引用する際は、原典に当たって記述を確認すること（嘘つかない原則）。

---

## ① レベル分けの根拠：熟達度逆転効果

> Kalyuga, S., Ayres, P., Chandler, P., & Sweller, J. (2003). The expertise reversal effect. *Educational Psychologist*, 38(1), 23–31. DOI: 10.1207/S15326985EP3801_4

**要旨**：初学者に有効な教え方（詳しい解説を足す、手順を全部見せる）を熟達者に適用すると、学習成果がむしろ下がる。学習者の事前知識と教授方法の間に統計的な交互作用が生じる現象。認知負荷理論における冗長性効果の一形態として最初に予測された。

**このスキルへの適用**：中級エンジニアに新人向けの逐次説明を付けるのは「親切」ではなく成果を下げる操作である。だから `level-junior.md` と `level-intermediate.md` を分け、判定を最初のステップに置いている。

関連（同じ研究系列で、いずれも本文中で参照されている）:
- Kalyuga, S., Chandler, P., & Sweller, J. (1998). Levels of expertise and instructional design. *Human Factors*, 40(1), 1–17.
- Kalyuga, S., Chandler, P., Tuovinen, J., & Sweller, J. (2001). When problem solving is superior to studying worked examples. *Journal of Educational Psychology*, 93(3), 579–588.
- Kalyuga, S., & Renkl, A. (2010). Expertise reversal effect and its instructional implications: Introduction to the special issue. *Instructional Science*, 38(3), 209–215. DOI: 10.1007/s11251-009-9102-0

---

## ② 新人には完成品、そこから段階的に手を離す：ワークトエグザンプルとフェーディング

> Renkl, A., & Atkinson, R. K. (2003). Structuring the transition from example study to problem solving in cognitive skill acquisition: A cognitive load perspective. *Educational Psychologist*, 38(1), 15–22. DOI: 10.1207/S15326985EP3801_3

**要旨**：技能習得の初期段階では、自力で問題を解くより完成した解答例を読むほうが効果的。後期段階では逆に、自力で解くほうが優れる。段階に応じて解答ステップを1つずつ消していく（フェーディング）ことで、この移行を滑らかにできる。

> Atkinson, R. K., Renkl, A., & Merrill, M. M. (2003). Transitioning from studying examples to solving problems: Effects of self-explanation prompts and fading worked-out steps. *Journal of Educational Psychology*, 95(4), 774–783. DOI: 10.1037/0022-0663.95.4.774

**要旨**：フェーディングだけでは近転移（似た問題への応用）には効くが、遠転移（違う文脈への応用）には安定して効かない。フェーディングに**自己説明プロンプト**（「この手順の背後にある原理を言葉にしてください」）を組み合わせると、その弱点を補える。

> Renkl, A., Atkinson, R. K., & Große, C. S. (2004). How fading worked solution steps works — A cognitive load perspective. *Instructional Science*, 32(1–2), 59–82.

**要旨**：消したステップの位置は成果に影響しなかった一方、学習者は**消された箇所の原理を最もよく学んだ**。フェーディングが自己説明活動を引き起こしているためと考えられる。

**このスキルへの適用**：`level-junior.md` の第1段〜第4段のフェーディング設計と、各段で「自分の言葉で説明してください」と促す運用は、この3本に直接対応している。

---

## ③ 定着させるなら再読より思い出す：テスティング効果

> Roediger, H. L., & Karpicke, J. D. (2006). Test-enhanced learning: Taking memory tests improves long-term retention. *Psychological Science*, 17(3), 249–255. DOI: 10.1111/j.1467-9280.2006.01693.x

**要旨**：文章を繰り返し読み直した群と、1回読んだあと思い出すテストを繰り返した群を比較。直後の再生では再読群が上回ったが、時間を置いた遅延テストでは検索練習群が大きく上回った。再読群のほうが「覚えられている」という自信は高かった。

> Roediger, H. L., Agarwal, P. K., McDaniel, M. A., & McDermott, K. B. (2011). Test-enhanced learning in the classroom: Long-term improvements from quizzing. *Journal of Experimental Psychology: Applied*, 17(4), 382–395.

**要旨**：実際の教室で、成績にほぼ影響しない低ストレスの小テストを繰り返す形で検証し、長期的な成績改善を確認。

**このスキルへの適用**：ツールを研修教材に使うとき、資料を再読させるより白紙に書き出させる。受講生の「もう一回読みます」を「思い出して書いてみましょう」に置き換える運用の根拠。

---

## ④ 説明抜きで探索させない：ガイドありの指導の優位

> Kirschner, P. A., Sweller, J., & Clark, R. E. (2006). Why minimal guidance during instruction does not work: An analysis of the failure of constructivist, discovery, problem-based, experiential, and inquiry-based teaching. *Educational Psychologist*, 41(2), 75–86. DOI: 10.1207/s15326985ep4102_1

**要旨**：ガイドの少ない指導法は直感的に魅力的だが、半世紀の実証研究は一貫して、ガイドを重視する指導法より効果も効率も低いことを示している。ガイドの優位性が薄れるのは、学習者が「内的なガイド」を持てるだけの事前知識を獲得した後に限られる。

**このスキルへの適用**：新人に「まずは自分で考えてみましょう」から入らない理由。ただし後半の但し書き（事前知識が十分なら逆転する）が①と接続しており、中級向けモードの根拠にもなっている。

**注記**：この論文は探究学習の研究者から反論を受けており、論争がある領域である。研修で引用するときは「この立場に立つ有力な論文がある」として扱い、決着済みの事実として語らない。

---

## ⑤ チェックリストが人の抜けを防ぐ：外科安全チェックリスト

> Haynes, A. B., Weiser, T. G., Berry, W. R., Lipsitz, S. R., Breizat, A.-H. S., Dellinger, E. P., Herbosa, T., Joseph, S., Kibatala, P. L., Lapitan, M. C. M., Merry, A. F., Moorthy, K., Reznick, R. K., Taylor, B., & Gawande, A. A., for the Safe Surgery Saves Lives Study Group (2009). A surgical safety checklist to reduce morbidity and mortality in a global population. *New England Journal of Medicine*, 360(5), 491–499. DOI: 10.1056/NEJMsa0810119

**要旨**：8か国の病院で19項目の外科安全チェックリストを導入し、術後合併症と死亡率の低下を報告した。高所得国・低中所得国の双方で効果が観察された。

**このスキルへの適用**：`test-checklist.md` を「毎回同じ順で読み上げる固定リスト」として運用する根拠。熟練者ほど「これは分かっている」と飛ばすが、飛ばした項目が抜ける。

**注記**：この研究には効果量の解釈をめぐる批判（前後比較デザイン、対照群の欠如、ベースライン死亡率の高さ）が同誌の Letters で提起されている。「チェックリストは有効」という一般論の傍証として扱い、具体的な削減率の数字を研修で断定的に引用しない。ソフトウェアQAへの外挿は本スキルの解釈であって、この論文が示した知見ではない。

---

## 引用時の注意（嘘つかない原則）

- **効果量を盛らない**。「◯%向上」という数字は条件依存で、条件を書かずに引用しない
- **分野をまたぐ外挿は外挿と書く**。医療のチェックリスト研究はソフトウェアテストの効果を証明していない
- **論争を伏せない**。④⑤には反論があり、それを含めて紹介するほうが受講生の思考の役に立つ
- 孫引きしない。研修資料に載せる前にDOIから原典に当たる
